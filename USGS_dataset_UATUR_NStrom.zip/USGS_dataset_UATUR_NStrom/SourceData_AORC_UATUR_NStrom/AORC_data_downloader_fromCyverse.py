#%% This scipt will download the netCDF files from the CyVerse data store
    # if all packages shown above are installed on your local python environment, 
    # you should be able to run this entire script without changing and the netCDF files
    # will download to a folder called "netCDF_files"
import os
import requests
from datetime import datetime
import xarray as xr
#%%
# Define the date range to download 
start_date = datetime(2013, 1, 1)
end_date = datetime(2023, 1, 1)


# Define the base URL and the target directory
# link to the 2013-2023 data on CyVerse
base_url = 'https://data.cyverse.org/dav-anon/iplant/projects/atur/Hydroclimate/nwm3/forcing/nc/hourly/precip/'
# name of the directory files will save to in local workspace 
target_dir = "netCDF_files"

# Ensure the target directory exists
os.makedirs(target_dir, exist_ok=True)

# Iterate over each month in the date range
current_date = start_date
while current_date <= end_date:
    # Format the filename as YYYYMM.nc
    filename = current_date.strftime("%Y%m") + ".nc"
    file_url = base_url + filename
    target_file_path = os.path.join(target_dir, filename)

    # Download the file
    response = requests.get(file_url)
    if response.status_code == 200:
        with open(target_file_path, 'wb') as file:
            file.write(response.content)
        print(f"Downloaded: {filename}")
    else:
        print(f"Failed to download: {filename}")

    # Move to the next month
    if current_date.month == 12:
        current_date = datetime(current_date.year + 1, 1, 1)
    else:
        current_date = datetime(current_date.year, current_date.month + 1, 1)

#%% Test open and reading the .nc file using xarray
year = '2020'; month = '03' # year & month of .nc file to view 

# reading in the file 
filename = f'{year}{month}.nc'
target_file_path = os.path.join(target_dir, filename)
ds = xr.open_dataset(target_file_path)
print(ds)