
Date Created: 08/19/2024
Created by: Nathan Strom, Urban ATUR 
Email: nstrom@arizona.edu

Overview
 - data includes daily runoff volumes, delineated basin shapefiles, and daily precipitation volumes for USGS basins

09482500
09484600
09486350
09486580
09486800

Datasets:
 	- AORC_PrecipVol_USGS_2014_23_UTC-7: calculated from AORC precipitation data
	- Basin_ShpFiles_USGS: calculated from USGS StreamStats tool
	- Daily_QVols_USGS: calculated from USGS streamflow data: https://waterdata.usgs.gov/az/nwis/rt